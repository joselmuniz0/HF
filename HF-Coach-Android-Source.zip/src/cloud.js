import { createClient } from '@supabase/supabase-js';

const $ = id => document.getElementById(id);
const CONFIG_KEY = 'hf_cloud_config';
const CONSENT_KEY = 'hf_share_consent';
let client = null;
let currentUser = null;

function status(message) { if ($('cloudStatus')) $('cloudStatus').textContent = message; }
function getConfig() { try { return JSON.parse(localStorage.getItem(CONFIG_KEY) || 'null'); } catch { return null; } }
function getConsent() { try { return JSON.parse(localStorage.getItem(CONSENT_KEY) || '{\"activity\":true,\"profiles\":true,\"evaluations\":true,\"coachNotes\":true,\"media\":true,\"confirmed\":false}'); } catch { return {}; } }
function setConsentUI(c) {
  for (const [key,id] of Object.entries({activity:'shareActivity',profiles:'shareProfiles',evaluations:'shareEvaluations',coachNotes:'shareCoachNotes',media:'shareMedia',confirmed:'consentConfirm'})) {
    if ($(id)) $(id).checked = !!c[key];
  }
  const allowed = new Set(c.athleteIds || []); document.querySelectorAll('.consentAthlete').forEach(el=>el.checked=allowed.has(el.value));
}
function initClient() {
  const c = getConfig();
  if (!c?.url || !c?.key) { client = null; status('Sin configurar. Ingresá la URL y la clave pública de Supabase.'); return; }
  client = createClient(c.url, c.key, { auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: false } });
  status('Servidor configurado. Iniciá sesión para sincronizar.');
}

$('saveCloud')?.addEventListener('click', () => {
  const url = $('sbUrl').value.trim(); const key = $('sbKey').value.trim();
  if (!url.startsWith('https://') || !key) return status('Ingresá una URL HTTPS válida y la clave pública del proyecto.');
  localStorage.setItem(CONFIG_KEY, JSON.stringify({url,key})); initClient();
});
$('clearCloud')?.addEventListener('click', async () => {
  if (client) await client.auth.signOut();
  localStorage.removeItem(CONFIG_KEY); client = null; currentUser = null;
  $('sbUrl').value = ''; $('sbKey').value = ''; status('Configuración local eliminada.');
});
$('saveConsent')?.addEventListener('click', () => {
  const c = {id:crypto.randomUUID(),activity:$('shareActivity').checked,profiles:$('shareProfiles').checked,evaluations:$('shareEvaluations').checked,coachNotes:$('shareCoachNotes').checked,media:$('shareMedia').checked,confirmed:$('consentConfirm').checked,athleteIds:[...document.querySelectorAll('.consentAthlete:checked')].map(x=>x.value),updated_at:new Date().toISOString()};
  if ((c.profiles || c.evaluations || c.coachNotes || c.media) && (!c.confirmed || !c.athleteIds.length)) return status('Confirmá la autorización y seleccioná al menos un atleta con permiso de intercambio.');
  localStorage.setItem(CONSENT_KEY, JSON.stringify(c)); status('Permisos de intercambio guardados en este dispositivo.');
});
$('mediaFiles')?.addEventListener('change', e => {
  $('mediaStatus').textContent = `${e.target.files.length} archivo(s) seleccionado(s). Se enviarán solo al sincronizar con permiso multimedia activo.`;
});
$('cloudLogin')?.addEventListener('click', async () => {
  try {
    if (!client) initClient(); if (!client) return;
    const {data,error} = await client.auth.signInWithPassword({email:$('cloudEmail').value.trim(),password:$('cloudPassword').value});
    if (error) throw error; currentUser = data.user; $('cloudPassword').value = '';
    status(`Sesión iniciada: ${currentUser.email}.`);
  } catch(e) { status(`No se pudo iniciar sesión: ${e.message || e}`); }
});
$('cloudLogout')?.addEventListener('click', async () => {
  if (!client) return; const {error} = await client.auth.signOut(); if (error) return status(error.message);
  currentUser = null; status('Sesión cerrada.');
});

async function syncNow() {
  if (!client) initClient(); if (!client) throw new Error('Falta configurar el servidor.');
  const {data:auth,error:authError} = await client.auth.getUser();
  if (authError || !auth.user) throw new Error('Iniciá sesión antes de sincronizar.');
  currentUser = auth.user;
  const {data:membership,error:memberError} = await client.from('organization_memberships').select('organization_id,role').eq('user_id',currentUser.id).limit(1).maybeSingle();
  if (memberError) throw memberError;
  if (!membership) throw new Error('Tu cuenta todavía no fue incorporada a una organización HF Coach. Solicitá el alta al administrador.');
  const orgId = membership.organization_id;
  const consent = getConsent();
  if (!consent.confirmed && (consent.profiles || consent.evaluations || consent.coachNotes || consent.media)) throw new Error('Falta confirmar la autorización de intercambio.');
  const store = window.HFStore;
  if (!store) throw new Error('No se pudo acceder al almacenamiento local.');
  const consentedIds = new Set(consent.athleteIds || []);
  const athletes = store.read('athletes').filter(a=>consentedIds.has(a.id)); const sessions = store.read('sessions').filter(s=>consentedIds.has(s.ath)); const evaluations = store.read('evaluations').filter(e=>consentedIds.has(e.athlete_id));
  let sent = 0;
  if ((consent.evaluations || consent.coachNotes || consent.media) && !consent.profiles) throw new Error('Para sincronizar sesiones, evaluaciones o archivos, habilitá también perfiles de atletas.');
  if (consent.profiles) {
    const rows = athletes.map(a => ({id:a.id,organization_id:orgId,owner_coach_id:currentUser.id,full_name:a.name,age:a.age?Number(a.age):null,level:a.level,sex:a.sex||null,body_weight_kg:a.weight?Number(a.weight):null,snatch_kg:a.snatch?Number(a.snatch):null,clean_jerk_kg:a.cj?Number(a.cj):null,notes:consent.coachNotes?(a.notes||null):null,updated_at:new Date().toISOString()}));
    if (rows.length) { const {error} = await client.from('athletes').upsert(rows); if (error) throw error; const assignments=rows.map(a=>({organization_id:orgId,athlete_id:a.id,coach_id:currentUser.id,assigned_by:currentUser.id})); const {error:assignError}=await client.from('coach_athletes').upsert(assignments); if(assignError) throw assignError; sent += rows.length; }
  }
  if (consent.coachNotes && consent.profiles) {
    const rows = sessions.map(s => ({id:s.id,organization_id:orgId,athlete_id:s.ath,created_by:currentUser.id,session_date:s.date,session_type:s.type,main_load_kg:s.load?Number(s.load):null,rpe:s.rpe?Number(s.rpe):null,notes:s.notes||null}));
    if (rows.length) { const {error} = await client.from('training_sessions').upsert(rows); if (error) throw error; sent += rows.length; }
  }
  if (consent.evaluations && consent.profiles) {
    const rows = evaluations.filter(e=>e.athlete_id).map(e=>({id:e.id,organization_id:orgId,athlete_id:e.athlete_id,created_by:currentUser.id,lift:e.lift,created_at:e.created_at,metrics:e.metrics,findings:e.findings,confidence:e.confidence,frame_count:e.frame_count,review_status:e.review_status,video_name:e.video_name}));
    if (rows.length) { const {error} = await client.from('evaluations').upsert(rows); if (error) throw error; sent += rows.length; }
  }
  if (consent.media) {
    if (!consent.confirmed) throw new Error('Se requiere autorización confirmada para compartir videos y fotografías.');
    const files = [...($('mediaFiles')?.files || [])];
    if (window.HFCurrentVideo && !files.some(f=>f.name===window.HFCurrentVideo.name && f.size===window.HFCurrentVideo.size)) files.push(window.HFCurrentVideo);
    if (files.length) {
      const athleteId = $('mediaAth')?.value || $('analysisAth')?.value;
      if (!athleteId || !consentedIds.has(athleteId)) throw new Error('Seleccioná un atleta con autorización de intercambio registrada.');
      for (const file of files) {
        const clean = file.name.replace(/[^a-z0-9._-]/gi,'_');
        const path = `${orgId}/${athleteId}/${Date.now()}-${clean}`;
        const {error:uploadError} = await client.storage.from('athlete-media').upload(path,file,{contentType:file.type||'application/octet-stream',upsert:false});
        if (uploadError) throw uploadError;
        const {error:metaError} = await client.from('media_assets').insert({organization_id:orgId,athlete_id:athleteId,uploaded_by:currentUser.id,object_path:path,file_name:file.name,mime_type:file.type||null,size_bytes:file.size});
        if (metaError) throw metaError; sent++;
      }
    }
  }
  if (consent.confirmed) {
    for (const athleteId of (consent.athleteIds||[])) {
      const {error} = await client.from('data_consents').insert({id:crypto.randomUUID(),organization_id:orgId,recorded_by:currentUser.id,subject_athlete_id:athleteId,scope:{activity:!!consent.activity,profiles:!!consent.profiles,evaluations:!!consent.evaluations,coach_notes:!!consent.coachNotes,media:!!consent.media},confirmed:true,recorded_at:consent.updated_at||new Date().toISOString()});
      if (error) throw error;
    }
  }
  if (consent.activity) {
    const syncedIds = JSON.parse(localStorage.getItem('hf_synced_activity_ids') || '[]');
    const pending = store.read('activity').filter(e=>!syncedIds.includes(e.id));
    const events = pending.map(e=>({id:e.id,organization_id:orgId,user_id:currentUser.id,event_type:e.action||'app_activity',details:e.details||{entity:e.entity||null},created_at:e.created_at}));
    if(events.length){const {error}=await client.from('activity_events').insert(events);if(error)throw error;localStorage.setItem('hf_synced_activity_ids',JSON.stringify([...syncedIds,...pending.map(e=>e.id)].slice(-5000)));sent+=events.length;}
    const {error} = await client.from('activity_events').insert({organization_id:orgId,user_id:currentUser.id,event_type:'manual_sync',details:{records_sent:sent,at:new Date().toISOString()}});
    if (error) throw error;
  }
  status(`Sincronización completada. Registros y archivos enviados: ${sent}.`);
  return sent;
}
$('cloudSync')?.addEventListener('click', async () => {
  status('Sincronizando…');
  try { await syncNow(); } catch(e) { status(`Sincronización incompleta: ${e.message || e}`); }
});

const cfg = getConfig(); if (cfg) { $('sbUrl').value = cfg.url; $('sbKey').value = cfg.key; }
setConsentUI(getConsent());
initClient();
