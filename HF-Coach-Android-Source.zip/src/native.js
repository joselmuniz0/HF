import { Capacitor } from '@capacitor/core';
import { Filesystem, Directory } from '@capacitor/filesystem';
import { Share } from '@capacitor/share';

window.HFNative = {
  isNative: Capacitor.isNativePlatform(),
  platform: Capacitor.getPlatform(),
  async preparePrivateFolder() {
    await Filesystem.mkdir({ path: 'HF Coach', directory: Directory.Data, recursive: true });
    await Filesystem.writeFile({
      path: 'HF Coach/README.txt',
      directory: Directory.Data,
      data: 'HF Coach: almacenamiento privado de la aplicación. Exportá los datos desde la app para compartirlos.'
    });
    return Filesystem.getUri({ path: 'HF Coach', directory: Directory.Data });
  },
  async exportText(filename, content) {
    const safe = filename.replace(/[^a-z0-9._-]/gi, '_');
    const result = await Filesystem.writeFile({ path: `HF Coach/${safe}`, directory: Directory.Cache, data: content });
    return Share.share({ title: 'Exportación HF Coach', text: `Archivo generado: ${safe}`, url: result.uri, dialogTitle: 'Compartir exportación' });
  }
};

const folderButton = document.getElementById('makeFolder');
if (folderButton) folderButton.addEventListener('click', async () => {
  const status = document.getElementById('folderStatus');
  try {
    const result = await window.HFNative.preparePrivateFolder();
    status.textContent = `Carpeta privada preparada (${Capacitor.getPlatform()}).`;
  } catch (e) {
    status.textContent = `No se pudo preparar la carpeta: ${e.message || e}`;
  }
});
