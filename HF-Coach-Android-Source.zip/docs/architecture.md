# Arquitectura HF Coach — piloto Android

## Componentes

- **Cliente Android:** Capacitor WebView; motor MediaPipe ejecutado en el dispositivo.
- **Persistencia local:** localStorage en esta primera iteración; carpeta privada Capacitor Filesystem para archivos auxiliares/exportaciones.
- **Identidad:** Supabase Auth.
- **Base central:** PostgreSQL administrado por Supabase.
- **Archivos:** Supabase Storage, bucket privado `athlete-media`.
- **Autorización:** Row Level Security; organización, rol admin/coach, propiedad y asignación explícita de atletas.
- **Intercambio:** sincronización manual activada por el coach y limitada por permisos de categoría.

## Flujos

1. El coach analiza el video en el dispositivo.
2. La app persiste una evaluación local con estado `pending`.
3. El coach revisa y decide si comparte.
4. Al sincronizar, la app autentica al usuario, verifica su membresía y envía solo las categorías habilitadas.
5. Los archivos se cargan al bucket privado y se registra su metadato.
6. El administrador central puede consultar los datos de la organización; los coaches solo los atletas propios o asignados.

## Evolución posterior

- IndexedDB para archivos y cola offline más robusta.
- Sincronización incremental con control de conflictos.
- Panel web administrativo.
- Portal de atleta con permisos de lectura.
- Registro de intervenciones y reevaluaciones desde interfaz.
- Exportación de informes y auditoría de consentimientos.
- HF Learning solo después de validar la calidad y consistencia de datos del piloto.
