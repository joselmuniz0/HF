# Privacidad, permisos y consentimiento

HF Coach debe distinguir entre permiso del sistema operativo y autorización para compartir datos con el servidor.

- El permiso del selector Android habilita acceso al archivo que el usuario selecciona; no autoriza por sí mismo subirlo.
- La casilla de intercambio multimedia habilita la categoría, pero el usuario debe seleccionar los archivos y ejecutar la sincronización.
- La confirmación de autorización es un control operativo adicional; no reemplaza el consentimiento informado ni las obligaciones legales aplicables.
- Para menores, debe existir autorización de madre, padre o responsable legal según corresponda.
- Las credenciales de cada coach son individuales. No compartir usuarios ni contraseñas.
- La clave `service_role` de Supabase nunca debe incluirse en el APK.
- Los videos deben almacenarse en un bucket privado, con permisos de acceso por organización y asignación de atleta.
- Debe definirse un plazo de retención, un procedimiento de revocación y un proceso de eliminación de datos.
