-- HF Coach - esquema inicial para Supabase/PostgreSQL
-- Ejecutar desde Supabase SQL Editor con un usuario administrador.
create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.organization_memberships (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','coach')),
  created_at timestamptz not null default now(),
  primary key (organization_id,user_id)
);

create table if not exists public.athletes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  owner_coach_id uuid not null references auth.users(id),
  full_name text not null,
  age integer,
  level text,
  sex text,
  body_weight_kg numeric(6,2),
  snatch_kg numeric(6,2),
  clean_jerk_kg numeric(6,2),
  notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.coach_athletes (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  athlete_id uuid not null references public.athletes(id) on delete cascade,
  coach_id uuid not null references auth.users(id) on delete cascade,
  assigned_by uuid not null references auth.users(id),
  assigned_at timestamptz not null default now(),
  primary key (athlete_id,coach_id)
);

create table if not exists public.training_sessions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  athlete_id uuid not null references public.athletes(id) on delete cascade,
  created_by uuid not null references auth.users(id),
  session_date date not null,
  session_type text not null,
  main_load_kg numeric(7,2),
  rpe numeric(3,1),
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.evaluations (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  athlete_id uuid not null references public.athletes(id) on delete cascade,
  created_by uuid not null references auth.users(id),
  lift text not null,
  created_at timestamptz not null default now(),
  metrics jsonb not null default '{}'::jsonb,
  findings jsonb not null default '[]'::jsonb,
  confidence numeric(5,4),
  frame_count integer,
  review_status text not null default 'pending' check (review_status in ('pending','reviewed','rejected')),
  coach_feedback text,
  video_name text
);

create table if not exists public.interventions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  athlete_id uuid not null references public.athletes(id) on delete cascade,
  evaluation_id uuid references public.evaluations(id) on delete set null,
  coach_id uuid not null references auth.users(id),
  problem_identified text not null,
  objective text,
  prescribed_exercises jsonb not null default '[]'::jsonb,
  load_and_volume jsonb not null default '{}'::jsonb,
  start_date date,
  reassessment_date date,
  outcome text,
  created_at timestamptz not null default now()
);

create table if not exists public.media_assets (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  athlete_id uuid not null references public.athletes(id) on delete cascade,
  uploaded_by uuid not null references auth.users(id),
  object_path text not null unique,
  file_name text not null,
  mime_type text,
  size_bytes bigint,
  created_at timestamptz not null default now()
);

create table if not exists public.data_consents (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  recorded_by uuid not null references auth.users(id),
  subject_athlete_id uuid references public.athletes(id) on delete cascade,
  scope jsonb not null,
  confirmed boolean not null default false,
  recorded_at timestamptz not null default now()
);

create table if not exists public.activity_events (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id),
  event_type text not null,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.is_org_member(org uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.organization_memberships m where m.organization_id=org and m.user_id=auth.uid()) $$;

create or replace function public.is_org_admin(org uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.organization_memberships m where m.organization_id=org and m.user_id=auth.uid() and m.role='admin') $$;

create or replace function public.can_access_athlete(aid uuid)
returns boolean language sql stable security definer set search_path = public
as $$
  select exists (
    select 1 from public.athletes a
    where a.id=aid and (
      public.is_org_admin(a.organization_id)
      or a.owner_coach_id=auth.uid()
      or exists (select 1 from public.coach_athletes ca where ca.athlete_id=a.id and ca.coach_id=auth.uid())
    )
  )
$$;

alter table public.organizations enable row level security;
alter table public.organization_memberships enable row level security;
alter table public.athletes enable row level security;
alter table public.coach_athletes enable row level security;
alter table public.training_sessions enable row level security;
alter table public.evaluations enable row level security;
alter table public.interventions enable row level security;
alter table public.media_assets enable row level security;
alter table public.data_consents enable row level security;
alter table public.activity_events enable row level security;

create policy "org members read organization" on public.organizations for select using (public.is_org_member(id));
create policy "members read memberships" on public.organization_memberships for select using (public.is_org_member(organization_id));
create policy "admins manage memberships" on public.organization_memberships for all using (public.is_org_admin(organization_id)) with check (public.is_org_admin(organization_id));

create policy "assigned coaches read athletes" on public.athletes for select using (public.can_access_athlete(id));
create policy "coaches create own athletes" on public.athletes for insert with check (public.is_org_member(organization_id) and owner_coach_id=auth.uid());
create policy "coaches update assigned athletes" on public.athletes for update using (public.can_access_athlete(id)) with check (public.can_access_athlete(id));
create policy "admins or owners delete athletes" on public.athletes for delete using (public.is_org_admin(organization_id) or owner_coach_id=auth.uid());

create policy "coaches read athlete assignments" on public.coach_athletes for select using (public.is_org_member(organization_id) and public.can_access_athlete(athlete_id));
create policy "admins assign coaches" on public.coach_athletes for all using (public.is_org_admin(organization_id)) with check (public.is_org_admin(organization_id));
create policy "coach can register own assignment" on public.coach_athletes for insert with check (public.is_org_member(organization_id) and coach_id=auth.uid() and assigned_by=auth.uid() and public.can_access_athlete(athlete_id));
create policy "coaches update own assignment" on public.coach_athletes for update using (coach_id=auth.uid() and public.can_access_athlete(athlete_id)) with check (coach_id=auth.uid() and public.can_access_athlete(athlete_id));

create policy "assigned coaches read sessions" on public.training_sessions for select using (public.can_access_athlete(athlete_id));
create policy "assigned coaches add sessions" on public.training_sessions for insert with check (public.can_access_athlete(athlete_id) and created_by=auth.uid() and public.is_org_member(organization_id));
create policy "assigned coaches update sessions" on public.training_sessions for update using (public.can_access_athlete(athlete_id)) with check (public.can_access_athlete(athlete_id));
create policy "assigned coaches delete sessions" on public.training_sessions for delete using (public.can_access_athlete(athlete_id));

create policy "assigned coaches read evaluations" on public.evaluations for select using (public.can_access_athlete(athlete_id));
create policy "assigned coaches add evaluations" on public.evaluations for insert with check (public.can_access_athlete(athlete_id) and created_by=auth.uid() and public.is_org_member(organization_id));
create policy "assigned coaches update evaluations" on public.evaluations for update using (public.can_access_athlete(athlete_id)) with check (public.can_access_athlete(athlete_id));

create policy "assigned coaches read interventions" on public.interventions for select using (public.can_access_athlete(athlete_id));
create policy "assigned coaches manage interventions" on public.interventions for all using (public.can_access_athlete(athlete_id) and coach_id=auth.uid()) with check (public.can_access_athlete(athlete_id) and coach_id=auth.uid() and public.is_org_member(organization_id));

create policy "assigned coaches read media metadata" on public.media_assets for select using (public.can_access_athlete(athlete_id));
create policy "assigned coaches add media metadata" on public.media_assets for insert with check (public.can_access_athlete(athlete_id) and uploaded_by=auth.uid() and public.is_org_member(organization_id));

create policy "coaches read consents" on public.data_consents for select using (public.is_org_admin(organization_id) or (subject_athlete_id is not null and public.can_access_athlete(subject_athlete_id)));
create policy "coaches record consents" on public.data_consents for insert with check (public.is_org_member(organization_id) and recorded_by=auth.uid());

create policy "users read own activity admins read org" on public.activity_events for select using (user_id=auth.uid() or public.is_org_admin(organization_id));
create policy "users add own activity" on public.activity_events for insert with check (user_id=auth.uid() and public.is_org_member(organization_id));
create policy "users update own activity" on public.activity_events for update using (user_id=auth.uid() or public.is_org_admin(organization_id)) with check (user_id=auth.uid() or public.is_org_admin(organization_id));

-- Bucket privado para videos y fotografías. Las rutas comienzan con el UUID de la organización.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('athlete-media','athlete-media',false,524288000,array['video/mp4','video/quicktime','video/webm','image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

create policy "org members read private athlete media" on storage.objects for select
using (bucket_id='athlete-media' and public.is_org_member((storage.foldername(name))[1]::uuid) and public.can_access_athlete((storage.foldername(name))[2]::uuid));
create policy "org members upload private athlete media" on storage.objects for insert
with check (bucket_id='athlete-media' and public.is_org_member((storage.foldername(name))[1]::uuid) and public.can_access_athlete((storage.foldername(name))[2]::uuid));
create policy "org members delete private athlete media" on storage.objects for delete
using (bucket_id='athlete-media' and public.is_org_member((storage.foldername(name))[1]::uuid) and public.can_access_athlete((storage.foldername(name))[2]::uuid));
