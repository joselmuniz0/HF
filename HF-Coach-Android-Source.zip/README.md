# HF Coach — Android (proyecto base)

Este paquete convierte la aplicación web de videoanálisis adjunta en la base de una app Android mediante Capacitor. Conserva el motor MediaPipe del original y añade una estructura inicial de atletas, sesiones, equipo local, evaluación persistida, permisos de intercambio y conexión opcional con Supabase.

## Estado real de esta entrega

- La interfaz web y el motor de videoanálisis están incluidos.
- La aplicación se puede compilar como APK con el workflow de GitHub Actions.
- Se incluye un esquema SQL para un backend central Supabase con roles, asignación de atletas, evaluaciones, sesiones, archivos privados, consentimientos y actividad.
- La conexión con Supabase requiere crear el proyecto, ejecutar `supabase/schema.sql`, crear la organización y las cuentas de los tres coaches, y configurar la URL y clave pública dentro de la app.
- No se incluye un APK ya compilado: este entorno de trabajo no dispone del Android SDK/Gradle instalado. El workflow genera el APK en GitHub Actions.
- El registro de coaches visible en el módulo Equipo es local y demostrativo; las identidades y permisos efectivos se resuelven mediante Supabase Auth y `organization_memberships`.

## Requisitos para compilar

- Node.js 20 o 22
- Java JDK 21
- Android Studio / Android SDK para compilar localmente, o GitHub Actions para compilar en la nube

## Compilar localmente

```bash
npm install
npm run build
npx cap add android
npx cap sync android
npx cap open android
```

En Android Studio, ejecutar la app o generar un APK desde **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Obtener el APK con GitHub Actions

1. Crear un repositorio privado en GitHub y subir el contenido de este directorio.
2. En GitHub, abrir **Actions**.
3. Ejecutar **Build HF Coach APK** con **Run workflow**.
4. Descargar el artefacto `HF-Coach-debug-apk` cuando finalice.
5. Instalar el APK en los teléfonos de prueba. Android solicitará autorizar la instalación desde esa fuente.

El APK de depuración sirve para el piloto. Para distribución pública o estable se debe generar una versión firmada (`release`) y custodiar la clave de firma fuera del repositorio.

## Configuración del backend

1. Crear un proyecto Supabase.
2. Ejecutar el contenido de `supabase/schema.sql` en SQL Editor.
3. Crear una organización y asignar los tres usuarios a `organization_memberships` con rol `coach`; asignar al responsable del proyecto rol `admin`. Ejemplo para ejecutar en SQL Editor después de crear los usuarios en Authentication:

```sql
insert into public.organizations(name) values ('HF Coach Piloto') returning id;
-- Reemplazar ORGANIZATION_UUID por el UUID devuelto y los correos por los usuarios reales.
insert into public.organization_memberships(organization_id,user_id,role)
select 'ORGANIZATION_UUID'::uuid, id, case when email='admin@tudominio.com' then 'admin' else 'coach' end
from auth.users
where email in ('admin@tudominio.com','coach1@tudominio.com','coach2@tudominio.com','coach3@tudominio.com');
```

No publicar el UUID ni los datos de acceso en repositorios públicos; los correos anteriores son marcadores de ejemplo.
4. En cada instalación, abrir **Intercambio**, ingresar Project URL y la clave pública `anon`/`publishable`, y entrar con el usuario creado en Supabase Auth.
5. Revisar y confirmar los permisos de intercambio antes de enviar datos o multimedia.

No introducir nunca la `service_role` key en la aplicación. La app solo debe contener la clave pública y todas las restricciones deben aplicarse mediante Row Level Security.

## Almacenamiento y permisos Android

- El selector de archivos del sistema permite que el usuario elija videos e imágenes sin solicitar acceso indiscriminado a toda la galería.
- Capacitor Filesystem crea una carpeta privada `HF Coach` dentro del espacio de datos de la aplicación. Ese espacio no requiere permiso general de almacenamiento.
- Si más adelante se necesita una carpeta pública visible en Documentos/Descargas o acceso persistente a un árbol de carpetas elegido por el usuario, se incorporará el selector nativo Android Storage Access Framework. No se solicitará `MANAGE_EXTERNAL_STORAGE` ni acceso general a archivos sin una necesidad justificada.
- Los videos se analizan localmente. La carga al servidor ocurre únicamente al sincronizar, con permiso multimedia y confirmación de autorización activados.

## Modelo de administración mixto

- Administrador: ve y administra la organización y sus asignaciones.
- Coach: gestiona atletas propios o asignados y sus evaluaciones.
- Atleta: se incorporará como rol de consulta en una iteración posterior; en esta versión no hay portal autenticado de atleta.

## Límites conocidos de esta versión

- El análisis técnico original utiliza estimaciones 2D desde un solo ángulo y umbrales heurísticos. Debe ser revisado por un coach; no es diagnóstico ni medición biomecánica de laboratorio.
- La sincronización actual es manual, no automática en segundo plano.
- La sincronización de sesiones y evaluaciones requiere que el atleta esté sincronizado primero.
- La app aún no tiene un panel web administrativo ni gestión de invitaciones de usuarios; el alta de cuentas y membresías se realiza desde Supabase.
- Los archivos multimedia se comparten en el bucket privado `athlete-media`, sujetos a RLS.

## Datos y privacidad

Para atletas menores de edad, obtener autorización de sus responsables antes de registrar o compartir datos y videos. Definir una política de retención y eliminación antes del piloto. La opción de compartir actividad no equivale a telemetría oculta: registra eventos operativos de la aplicación y sincronizaciones que el usuario habilita.
